| Feature | Description |
| --- | --- |
| **Name** | `en_textcat_demo` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.6.0,<3.7.0` |
| **Default Pipeline** | `textcat` |
| **Components** | `textcat` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (14 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat`** | `DOUBT`, `FEAR`, `VIOLENCE`, `GREETING`, `GOODBYE`, `THANKS`, `ANGER`, `CONFUSION`, `TRANSITION`, `INFORMATION`, `AGREEMENT`, `CON`, `EXC`, `AGR` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 42.37 |
| `CATS_MICRO_P` | 55.77 |
| `CATS_MICRO_R` | 55.77 |
| `CATS_MICRO_F` | 55.77 |
| `CATS_MACRO_P` | 42.53 |
| `CATS_MACRO_R` | 47.42 |
| `CATS_MACRO_F` | 42.37 |
| `CATS_MACRO_AUC` | 75.50 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_LOSS` | 0.00 |